

<?php $__env->startSection('title', 'Détails vente'); ?>

<?php $__env->startSection('content'); ?>
<div class="product-details">
    <div class="row">
        <div class="col-6">
            <h4>Détails de la vente</h4>
        </div>
        <div class="col-6 valider-button">
            <a href="<?php echo e(route('vente.valider', $produit->id)); ?>" class="btn btn-primary valider-button"><i class="fas fa-check"></i> Valider</a>
            <a href="<?php echo e(route('vente.refuser', $produit->id)); ?>" class="btn btn-warning valider-button"><i class="fas fa-trash"></i> Refuser</a>
        </div>
    </div>
    <table class="table ventes-list">
        <tbody>
            <tr>
                <th scope="row">Id:</th>
                <td><?php echo e($produit->id); ?></td>
            </tr>
            <tr>
                <th scope="row">Titre:</th>
                <td><?php echo e($produit->titre); ?></td>
            </tr>
            <tr>
                <th scope="row">Description:</th>
                <td><?php echo e($produit->description); ?></td>
            </tr>
            <tr>
                <th scope="row">Prix:</th>
                <td><?php echo e($produit->prix); ?></td>
            </tr>
            <tr>
                <th scope="row">État:</th>
                <td><?php echo e($produit->etat); ?></td>
            </tr>
            <tr>
                <th scope="row">Catégorie:</th>
                <td><?php echo e($produit->categorie); ?></td>
            </tr>
            <tr>
                <th scope="row">Utilisateur:</th>
                <td><?php echo e($produit->utilisateur); ?></td>
            </tr>
            <tr>
                <th scope="row">Ville:</th>
                <td><?php echo e($produit->ville); ?></td>
            </tr>
            <tr>
                <th scope="row">Pays:</th>
                <td><?php echo e($produit->pays); ?></td>
            </tr>
            <tr>
                <th scope="row">Condition:</th>
                <td><?php echo e($produit->condition_); ?></td>
            </tr>
        </tbody>
    </table>

    <?php $__currentLoopData = $produit->photos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <img class="product-image" src="<?php echo e($photo->url); ?>" alt="Product Image">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Visual Studio Code\Webcup\WebCup-Competition\Back-End\resources\views/vente/details.blade.php ENDPATH**/ ?>