<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
</head>

<body>
    <div class="container centered-form">
        <div class="card p-4">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nom">Nom d'utilisateur:</label>
                    <input type="text" class="form-control" id="nom" name="nom" value="techmavericks" required>
                </div>

                <div class="form-group">
                    <label for="mdp">Mot de passe:</label>
                    <input type="password" class="form-control" id="mdp" name="mdp" value="rollback001" required>
                </div>

                <div class="button-wrapper">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Projects\Visual Studio Code\Webcup\WebCup-Competition\Back-End\resources\views/utilisateur/login.blade.php ENDPATH**/ ?>