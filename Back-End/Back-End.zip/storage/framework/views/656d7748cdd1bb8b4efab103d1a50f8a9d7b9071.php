

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="create-form">
    <h4>Modification de categorie</h4>
    <form method="POST" action="<?php echo e(route('categories.update', ['category' => $category->id])); ?>" class="row">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?> <!-- Use PUT method for updating -->
        <div class="col-6">
            <div class="form-group">
                <label for="nom">Nom :</label>
                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e($category->nom); ?>" required>
            </div>
        </div>
        <div class="col-12">
            <div class="row">
                <div class="col-6">
                    <div class="button-wrapper">
                        <button type="submit" class="btn btn-primary">Valider</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Visual Studio Code\Webcup\WebCup-Competition\Back-End\resources\views/categorie/edit.blade.php ENDPATH**/ ?>