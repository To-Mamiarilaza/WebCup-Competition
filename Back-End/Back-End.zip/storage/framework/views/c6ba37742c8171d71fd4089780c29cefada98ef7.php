<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <style>
        .centered-form {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .centered-form .button-wrapper {
            text-align: right;
            margin-top: 5px;
        }

        /* Style for list items */
        .alert ul {
            list-style-type: none; /* Remove bullets */
            padding: 0; /* Remove default padding */
            margin: 0; /* Remove default margin */
        }
    </style>
</head>

<body>
    <div class="container centered-form">
        <div class="card p-4">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nom">Nom d'utilisateur:</label>
                    <input type="text" class="form-control" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required>
                </div>

                <div class="form-group">
                    <label for="mdp">Mot de passe:</label>
                    <input type="password" class="form-control" id="mdp" name="mdp" required>
                </div>

                <div class="button-wrapper">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Projects\Visual Studio Code\Webcup\WebcupLaravel\resources\views/utilisateur/login.blade.php ENDPATH**/ ?>