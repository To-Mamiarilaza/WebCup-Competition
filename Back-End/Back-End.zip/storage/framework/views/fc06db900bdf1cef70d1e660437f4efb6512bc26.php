

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="category-list">
    <h4>Liste des ventes a valider</h4>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Titre</th>
                <th>Prix</th>
                <th>Catégorie</th>
                <th>Utilisateur</th>
                <th>Ville</th>
                <th>Pays</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($produit->titre); ?></td>
                <td><?php echo e($produit->prix); ?></td>
                <td><?php echo e($produit->categorie); ?></td>
                <td><?php echo e($produit->utilisateur); ?></td>
                <td><?php echo e($produit->ville); ?></td>
                <td><?php echo e($produit->pays); ?></td>
                <td>
                    <a href="<?php echo e(route('produit.details', $produit->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-info"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Visual Studio Code\Webcup\WebCup-Competition\Back-End\resources\views/vente/index.blade.php ENDPATH**/ ?>